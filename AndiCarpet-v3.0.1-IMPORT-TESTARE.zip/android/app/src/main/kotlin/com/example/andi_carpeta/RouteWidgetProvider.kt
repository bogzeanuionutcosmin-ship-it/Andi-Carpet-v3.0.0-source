package com.example.andi_carpeta

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.time.LocalDate
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject

/** Native route widget backed by an explicitly synchronized local snapshot. */
class RouteWidgetProvider : AppWidgetProvider() {
    companion object {
        private const val PREFS = "andi_route_widget"
        private const val ACTION_PAGE = "andi.route.PAGE"
        private const val ACTION_DAY = "andi.route.DAY"
        private const val ACTION_REFRESH = "android.intent.action.DATE_CHANGED"
        private const val KEY_SNAPSHOT = "snapshot"
        private const val KEY_UPDATED = "updated_at"
        fun save(context: Context, snapshot: String) {
            // Reject malformed payloads instead of replacing the last usable snapshot.
            require(snapshot.length <= 500_000) { "Snapshot prea mare" }
            val payload = JSONObject(snapshot)
            val days = payload.getJSONArray("days")
            require(days.length() <= 366) { "Prea multe zile în snapshot" }
            for (dayIndex in 0 until days.length()) {
                val day = days.getJSONObject(dayIndex)
                val date = day.getString("date")
                require(Regex("\\d{4}-\\d{2}-\\d{2}").matches(date) && runCatching { LocalDate.parse(date) }.isSuccess) { "Dată invalidă" }
                val stops = day.getJSONArray("stops")
                require(stops.length() <= 300) { "Prea multe opriri" }
                for (stopIndex in 0 until stops.length()) {
                    val stop = stops.getJSONObject(stopIndex)
                    require(stop.optString("name").length <= 250) { "Nume locație prea lung" }
                    val hasLat = stop.has("lat") && !stop.isNull("lat")
                    val hasLon = stop.has("lon") && !stop.isNull("lon")
                    require(hasLat == hasLon) { "Coordonate incomplete" }
                    if (hasLat) {
                        val lat = stop.getDouble("lat")
                        val lon = stop.getDouble("lon")
                        require(lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) { "Coordonate invalide" }
                    }
                }
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_SNAPSHOT, snapshot).putLong(KEY_UPDATED, System.currentTimeMillis()).apply()
            refresh(context)
        }
        fun clear(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
            refresh(context)
        }
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, RouteWidgetProvider::class.java))
            if (ids.isNotEmpty()) RouteWidgetProvider().onUpdate(context, manager, ids)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == Intent.ACTION_DATE_CHANGED || intent.action == Intent.ACTION_TIMEZONE_CHANGED || intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            refresh(context)
            return
        }
        if (intent.action != ACTION_PAGE && intent.action != ACTION_DAY) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
        if (id < 0) return
        if (intent.action == ACTION_DAY) {
            val days = try { JSONObject(prefs.getString(KEY_SNAPSHOT, "{}") ?: "{}").optJSONArray("days") ?: JSONArray() } catch (_: Exception) { JSONArray() }
            if (days.length() == 0) return
            val currentDate = prefs.getString("selected_date_$id", null)
            val currentIndex = (0 until days.length()).firstOrNull { days.optJSONObject(it)?.optString("date") == currentDate }
                ?: prefs.getInt("day_$id", 0).coerceIn(0, days.length() - 1)
            val next = (currentIndex + intent.getIntExtra("delta", 0)).coerceIn(0, days.length() - 1)
            prefs.edit().putInt("day_$id", next)
                .putString("selected_date_$id", days.optJSONObject(next)?.optString("date"))
                .putInt("page_$id", 0).apply()
        } else {
            val next = prefs.getInt("page_$id", 0) + intent.getIntExtra("delta", 0)
            prefs.edit().putInt("page_$id", next.coerceAtLeast(0)).apply()
        }
        onUpdate(context, AppWidgetManager.getInstance(context), intArrayOf(id))
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val snapshot = try { JSONObject(prefs.getString(KEY_SNAPSHOT, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val days = snapshot.optJSONArray("days") ?: JSONArray()
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.route_widget)
            val today = LocalDate.now().toString()
            val firstCurrent = (0 until days.length()).firstOrNull { index ->
                val d = days.optJSONObject(index) ?: return@firstOrNull false
                val stops = d.optJSONArray("stops") ?: JSONArray()
                d.optString("date") >= today && (0 until stops.length()).any { i ->
                    val status = stops.optJSONObject(i)?.optString("status")?.lowercase() ?: ""
                    status !in setOf("completed", "done", "finished", "finalizata", "finalizată", "refused", "refuzata", "refuzată")
                }
            } ?: (0 until days.length()).firstOrNull { (days.optJSONObject(it)?.optString("date") ?: "") >= today } ?: 0
            val selectedDate = prefs.getString("selected_date_$id", null)
            val selected = if (selectedDate != null) (0 until days.length()).firstOrNull {
                days.optJSONObject(it)?.optString("date") == selectedDate
            } ?: firstCurrent else firstCurrent
            val dayIndex = selected.coerceIn(0, (days.length() - 1).coerceAtLeast(0))
            val day = days.optJSONObject(dayIndex)
            if (selectedDate != null && selectedDate != day?.optString("date")) {
                prefs.edit().remove("selected_date_$id").putInt("page_$id", 0).apply()
            }
            val stops = day?.optJSONArray("stops") ?: JSONArray()
            val maxPage = ((stops.length() - 1).coerceAtLeast(0)) / 3
            val page = prefs.getInt("page_$id", 0).coerceIn(0, maxPage)
            val updatedAt = prefs.getLong(KEY_UPDATED, 0L)
            val stale = updatedAt <= 0L || System.currentTimeMillis() - updatedAt > 6 * 60 * 60 * 1000L
            views.setTextViewText(R.id.route_day, if (day == null) "Traseul nu este sincronizat" else "${day.optString("date", "Zi")} · ${page + 1}/${maxPage + 1}${if (stale) " · date vechi" else ""}")
            val labels = intArrayOf(R.id.route_stop_1, R.id.route_stop_2, R.id.route_stop_3)
            val maps = intArrayOf(R.id.route_maps_1, R.id.route_maps_2, R.id.route_maps_3)
            val waze = intArrayOf(R.id.route_waze_1, R.id.route_waze_2, R.id.route_waze_3)
            for (slot in 0..2) {
                val stop = stops.optJSONObject(page * 3 + slot)
                val name = stop?.optString("name")?.takeIf { it.isNotBlank() }
                views.setTextViewText(labels[slot], name ?: "—")
                val lat = stop?.optDouble("lat", Double.NaN) ?: Double.NaN
                val lon = stop?.optDouble("lon", Double.NaN) ?: Double.NaN
                val valid = lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0
                views.setTextViewText(maps[slot], if (valid) "Maps" else "")
                views.setTextViewText(waze[slot], if (valid) "Waze" else "")
                if (valid) {
                    val mapsUri = Uri.parse("google.navigation:q=$lat,$lon")
                    val wazeUri = Uri.parse("https://waze.com/ul?ll=$lat%2C$lon&navigate=yes")
                    views.setOnClickPendingIntent(maps[slot], navigation(context, mapsUri, id, slot, "maps"))
                    views.setOnClickPendingIntent(waze[slot], navigation(context, wazeUri, id, slot, "waze"))
                } else {
                    views.setOnClickPendingIntent(maps[slot], null)
                    views.setOnClickPendingIntent(waze[slot], null)
                }
            }
            views.setOnClickPendingIntent(R.id.route_prev_page, action(context, id, ACTION_PAGE, -1, 1))
            views.setOnClickPendingIntent(R.id.route_next_page, action(context, id, ACTION_PAGE, 1, 2))
            views.setOnClickPendingIntent(R.id.route_prev_day, action(context, id, ACTION_DAY, -1, 3))
            views.setOnClickPendingIntent(R.id.route_next_day, action(context, id, ACTION_DAY, 1, 4))
            manager.updateAppWidget(id, views)
        }
    }

    private fun navigation(context: Context, uri: Uri, widgetId: Int, slot: Int, provider: String): PendingIntent {
        // Unique per widget and visible slot; FLAG_UPDATE_CURRENT replaces an old destination.
        val code = (widgetId * 16 + slot * 2 + if (provider == "waze") 1 else 0)
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // The destination URI is part of Intent identity; cancel the previous token for this slot.
        return PendingIntent.getActivity(context, code, intent, PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun action(context: Context, id: Int, name: String, delta: Int, code: Int): PendingIntent {
        val intent = Intent(context, RouteWidgetProvider::class.java).setAction(name)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra("delta", delta)
        return PendingIntent.getBroadcast(context, id * 10 + code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
