/// Privacy-preserving OCR correction learning.
/// Stores normalized field locations and aggregate counters, never raw receipts.
import 'dart:math' as math;

class OcrFieldPosition {
  final String field;
  final double left, top, right, bottom;
  const OcrFieldPosition(this.field, this.left, this.top, this.right, this.bottom);

  bool get valid => [left, top, right, bottom].every((n) => n.isFinite && n >= 0 && n <= 1) && left < right && top < bottom;

  Map<String, Object> toJson() => {'field': field, 'l': left, 't': top, 'r': right, 'b': bottom};
}

class OcrObservedText {
  final String text;
  final OcrFieldPosition position;
  const OcrObservedText(this.text, this.position);
}

class OcrCorrectionMatch {
  final OcrFieldPosition? position;
  final bool ambiguous;
  const OcrCorrectionMatch(this.position, this.ambiguous);
}

String _normalizeOcrValue(String value) => value.toLowerCase()
    .replaceAll('ă', 'a').replaceAll('â', 'a').replaceAll('î', 'i')
    .replaceAll('ș', 's').replaceAll('ş', 's')
    .replaceAll('ț', 't').replaceAll('ţ', 't')
    .replaceAll(RegExp(r'[^a-z0-9]'), '');

/// Returns no position when the confirmed text has zero or multiple matches.
/// Never guesses between identical occurrences on the document.
OcrCorrectionMatch findConfirmedOcrPosition(String field, String confirmed, List<OcrObservedText> blocks) {
  final target = _normalizeOcrValue(confirmed);
  if (target.isEmpty) return const OcrCorrectionMatch(null, false);
  final matches = blocks.where((b) => b.position.valid && _normalizeOcrValue(b.text) == target).toList();
  if (matches.length != 1) return OcrCorrectionMatch(null, matches.length > 1);
  final p = matches.single.position;
  return OcrCorrectionMatch(OcrFieldPosition(field, p.left, p.top, p.right, p.bottom), false);
}

class OcrLearningStatistics {
  int verifiedDocuments = 0;
  int unchangedDocuments = 0;
  int verifiedFields = 0;
  int correctFields = 0;
  final List<bool> _recentUnchanged = [];
  final List<List<int>> _recentFieldCounts = [];

  void recordVerification({required int fieldsChecked, required int fieldsCorrect}) {
    if (fieldsChecked <= 0 || fieldsCorrect < 0 || fieldsCorrect > fieldsChecked) {
      throw ArgumentError('Invalid verified OCR field counts');
    }
    verifiedDocuments++;
    verifiedFields += fieldsChecked;
    correctFields += fieldsCorrect;
    final unchanged = fieldsChecked == fieldsCorrect;
    if (unchanged) unchangedDocuments++;
    _recentUnchanged.add(unchanged);
    _recentFieldCounts.add([fieldsChecked, fieldsCorrect]);
    if (_recentFieldCounts.length > 100) _recentFieldCounts.removeAt(0);
    if (_recentUnchanged.length > 100) _recentUnchanged.removeAt(0);
  }

  /// Restore aggregate counters without treating unverified documents as successes.
  factory OcrLearningStatistics.fromJson(Map<String, dynamic> json) {
    final stats = OcrLearningStatistics();
    int nonNegative(Object? value) => value is int && value >= 0 ? value : 0;
    stats.verifiedDocuments = nonNegative(json['verifiedDocuments']);
    stats.unchangedDocuments = math.min(nonNegative(json['unchangedDocuments']), stats.verifiedDocuments);
    stats.verifiedFields = nonNegative(json['verifiedFields']);
    stats.correctFields = math.min(nonNegative(json['correctFields']), stats.verifiedFields);
    final recent = json['recentUnchanged'];
    if (recent is List) stats._recentUnchanged.addAll(recent.whereType<bool>().toList().reversed.take(100).toList().reversed);
    final counts = json['recentFieldCounts'];
    if (counts is List) {
      for (final item in counts) {
        if (item is List && item.length == 2 && item[0] is int && item[1] is int && item[0] > 0 && item[1] >= 0 && item[1] <= item[0]) {
          stats._recentFieldCounts.add([item[0] as int, item[1] as int]);
        }
      }
      if (stats._recentFieldCounts.length > 100) stats._recentFieldCounts.removeRange(0, stats._recentFieldCounts.length - 100);
    }
    return stats;
  }

  double? get fieldAccuracy => verifiedFields == 0 ? null : correctFields / verifiedFields;
  double? get unchangedDocumentRate => verifiedDocuments == 0 ? null : unchangedDocuments / verifiedDocuments;
  double? unchangedRateForLast(int count) {
    if (count != 10 && count != 50 && count != 100) throw ArgumentError('Window must be 10, 50 or 100');
    if (_recentUnchanged.isEmpty) return null;
    final window = _recentUnchanged.skip(math.max(0, _recentUnchanged.length - count));
    final values = window.toList();
    return values.where((v) => v).length / values.length;
  }

  double? fieldAccuracyForLast(int count) {
    if (count != 10 && count != 50 && count != 100) throw ArgumentError('Window must be 10, 50 or 100');
    final window = _recentFieldCounts.skip(math.max(0, _recentFieldCounts.length - count));
    var checked = 0;
    var correct = 0;
    for (final entry in window) { checked += entry[0]; correct += entry[1]; }
    return checked == 0 ? null : correct / checked;
  }

  Map<String, Object> toJson() => {
    'verifiedDocuments': verifiedDocuments,
    'unchangedDocuments': unchangedDocuments,
    'verifiedFields': verifiedFields,
    'correctFields': correctFields,
    'recentUnchanged': _recentUnchanged,
    'recentFieldCounts': _recentFieldCounts,
  };
}

/// Separate merchant + document type prevents cross-merchant contamination.
class OcrPositionLearning {
  final String merchantKey;
  final String documentType;
  final Map<String, List<OcrFieldPosition>> _examples = {};
  OcrLearningStatistics statistics = OcrLearningStatistics();
  final List<String> _recordedDocumentIds = [];

  bool wasDocumentRecorded(String id) => _recordedDocumentIds.contains(id);

  void markDocumentRecorded(String id) {
    if (id.isEmpty || _recordedDocumentIds.contains(id)) return;
    _recordedDocumentIds.add(id);
    if (_recordedDocumentIds.length > 2000) {
      _recordedDocumentIds.removeRange(0, _recordedDocumentIds.length - 2000);
    }
  }

  OcrPositionLearning({required String merchant, required this.documentType})
      : merchantKey = _normalizeOcrValue(merchant) {
    if (merchantKey.isEmpty || documentType.trim().isEmpty) throw ArgumentError('Merchant and document type required');
  }

  factory OcrPositionLearning.fromJson(Map<String, dynamic> json) {
    final learning = OcrPositionLearning(
      merchant: (json['merchantKey'] ?? '').toString(),
      documentType: (json['documentType'] ?? '').toString(),
    );
    final positions = json['positions'];
    if (positions is Map) {
      for (final entry in positions.entries) {
        if (entry.key is! String || entry.value is! List) continue;
        for (final raw in entry.value as List) {
          if (raw is! Map) continue;
          final l = raw['l'], t = raw['t'], r = raw['r'], b = raw['b'];
          if (l is! num || t is! num || r is! num || b is! num) continue;
          final point = OcrFieldPosition(entry.key as String, l.toDouble(), t.toDouble(), r.toDouble(), b.toDouble());
          if (point.valid) learning.addConfirmedPosition(point);
        }
      }
    }
    final recorded = json['recordedDocumentIds'];
    if (recorded is List) {
      for (final id in recorded.whereType<String>().take(2000)) {
        learning.markDocumentRecorded(id);
      }
    }
    final stats = json['statistics'];
    if (stats is Map) {
      learning.statistics = OcrLearningStatistics.fromJson(Map<String, dynamic>.from(stats));
    }
    return learning;
  }

  void addConfirmedPosition(OcrFieldPosition position) {
    if (!position.valid || position.field.trim().isEmpty) throw ArgumentError('Invalid normalized OCR position');
    final samples = _examples.putIfAbsent(position.field, () => []);
    samples.add(position);
    // Keep a bounded sample history for compact, privacy-preserving learning.
    if (samples.length > 100) samples.removeRange(0, samples.length - 100);
  }

  /// Suggestions only after three compatible confirmed examples.
  OcrFieldPosition? suggest(String field) {
    final points = _examples[field];
    if (points == null || points.length < 3) return null;
    double median(Iterable<double> values) {
      final ordered = values.toList()..sort();
      final middle = ordered.length ~/ 2;
      return ordered.length.isOdd ? ordered[middle] : (ordered[middle - 1] + ordered[middle]) / 2;
    }
    final result = OcrFieldPosition(field, median(points.map((p) => p.left)), median(points.map((p) => p.top)), median(points.map((p) => p.right)), median(points.map((p) => p.bottom)));
    return result.valid ? result : null;
  }

  Map<String, Object> toJson() => {
    'merchantKey': merchantKey,
    'documentType': documentType,
    'positions': _examples.map((key, value) => MapEntry(key, value.map((p) => p.toJson()).toList())),
    'statistics': statistics.toJson(),
    'recordedDocumentIds': _recordedDocumentIds,
  };
}
