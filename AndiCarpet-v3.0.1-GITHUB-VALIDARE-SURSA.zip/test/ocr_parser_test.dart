import 'package:flutter_test/flutter_test.dart';
import 'package:andi_carpeta/ocr_parser.dart';

void main() {
  test('OCR parser extrage datele uzuale din bon', () {
    final result = parseFiscalOcr('''
SC EXEMPLU SRL
BON FISCAL NR 12345
DATA 05.10.2026
TOTAL 148,75 LEI
''');
    expect(result.documentNumber, contains('12345'));
    expect(result.amount, closeTo(148.75, 0.01));
    expect(result.date, DateTime(2026, 10, 5));
    expect(result.supplier.toUpperCase(), contains('SRL'));
  });

  test('OCR parser recunoaște document de carburant', () {
    final result = parseFiscalOcr('''
OMV PETROM
MOTORINA
42,50 L
7,25 LEI/L
TOTAL 308,13 LEI
''');
    expect(result.looksLikeFuel, isTrue);
    expect(result.liters, closeTo(42.5, 0.01));
    expect(result.pricePerLiter, closeTo(7.25, 0.01));
  });
}
